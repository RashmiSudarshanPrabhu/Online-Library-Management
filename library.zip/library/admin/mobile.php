<?php
session_start();
include('includes/config.php');
error_reporting(0);

if(strlen($_SESSION['alogin'])==0) {   
    header('location:index.php');
} else {
    if(isset($_POST['update'])) {
        $mobile = $_POST['mobile'];
        $newmobile = $_POST['newmobile'];
        $username = $_SESSION['alogin'];
        $sql = "SELECT mobilenumber FROM admin WHERE UserName=:username AND mobilenumber=:mobile";
        $query = $dbh->prepare($sql);
        $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $query->bindParam(':username', $username, PDO::PARAM_STR);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);
        if($query->rowCount() > 0) {
            if(strlen($newmobile) == 10) {
                $con = "UPDATE admin SET mobilenumber = :newmobile WHERE UserName = :username";
                $chngpwd1 = $dbh->prepare($con);
                $chngpwd1->bindParam(':newmobile', $newmobile, PDO::PARAM_STR);
                $chngpwd1->bindParam(':username', $username, PDO::PARAM_STR);
                $chngpwd1->execute();
                $msg = "Your mobile number has been successfully changed";
            } else {
                $error = "New mobile number must be exactly 10 digits";  
            }
        } else {
            $error = "Your current mobile number is incorrect";  
        }
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | </title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style>
        .errorWrap {
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #dd3d36;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .succWrap{
            padding: 10px;
            margin: 0 0 20px 0;
            background: #fff;
            border-left: 4px solid #5cb85c;
            -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
    </style>
</head>
<body>
    <!-- MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Change mobile number</h4>
                </div>
            </div>
            <!-- LOGIN PANEL START -->           
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                    <div class="panel panel-info">
                        <div class="panel-heading">Change Number</div>
                        <div class="panel-body">
                            <?php if(isset($error)) { ?>
                                <div class="errorWrap"><?php echo htmlentities($error); ?></div>
                            <?php } ?>
                            <?php if(isset($msg)) { ?>
                                <div class="succWrap"><?php echo htmlentities($msg); ?></div>
                            <?php } ?>
                            <form role="form" method="post" name="chngpwd">
                                <div class="form-group">
                                    <label>Current Mobile Number</label>
                                    <input class="form-control" type="text" name="mobile" autocomplete="off" required onkeypress="return onlyNumbers(event, 'mobile')" />
                                </div>
                                <div class="form-group">
                                    <label>Enter New Mobile Number</label>
                                    <input class="form-control" type="text" name="newmobile" autocomplete="off" required onkeypress="return onlyNumbers(event, 'newmobile')" />
                                </div>
                                <div id="mobileError" style="color: red;"></div> <!-- Error message display -->
                                <button type="submit" name="update" class="btn btn-info">Change</button> 
                            </form>
                        </div>
                    </div>
                </div>
            </div>  
            <!---LOGIN PANEL END-->            
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
    <script>
        function onlyNumbers(event, fieldName) {
            var charCode = (event.which) ? event.which : event.keyCode;
            if (charCode < 48 || charCode > 57) {
                // If input is not a digit, prevent input
                return false;
            }
            // Check the length of the input
            var inputValue = event.target.value + String.fromCharCode(charCode);
            if (inputValue.length > 10) {
                // If length exceeds 10, prevent input
                return false;
            }
            if (inputValue.length < 10) {
                // If length is less than 10, display error message
                document.getElementById('mobileError').innerHTML = "Mobile number must be exactly 10 digits";
            } else {
                // If length is 10, clear error message
                document.getElementById('mobileError').innerHTML = "";
            }
            // Allow input
            return true;
        }
    </script>
</body>
</html>

<?php  ?>
