<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
} else {
    if(isset($_POST['issue'])) {
        $studentid = strtoupper($_POST['studentid']);
        $bookid = $_POST['bookid'];

        // Check if the student has already been issued a book with the same ISBN
        $sql_check_already_issued = "SELECT * FROM tblissuedbookdetails WHERE StudentID = :studentid AND BookId IN (SELECT id FROM tblbooks WHERE ISBNNumber = (SELECT ISBNNumber FROM tblbooks WHERE id = :bookid))";
        $query_check_already_issued = $dbh->prepare($sql_check_already_issued);
        $query_check_already_issued->bindParam(':studentid', $studentid, PDO::PARAM_STR);
        $query_check_already_issued->bindParam(':bookid', $bookid, PDO::PARAM_STR);
        $query_check_already_issued->execute();

        if($query_check_already_issued->rowCount() == 0) {
            // Proceed with issuing the book
            issueBook($dbh, $studentid, $bookid);
        } else {
            // Check if the book with the same ISBN has been returned
            $sql_check_returned = "SELECT * FROM tblissuedbookdetails WHERE StudentID = :studentid AND BookId IN (SELECT id FROM tblbooks WHERE ISBNNumber = (SELECT ISBNNumber FROM tblbooks WHERE id = :bookid)) AND RetrunStatus = 1";
            $query_check_returned = $dbh->prepare($sql_check_returned);
            $query_check_returned->bindParam(':studentid', $studentid, PDO::PARAM_STR);
            $query_check_returned->bindParam(':bookid', $bookid, PDO::PARAM_STR);
            $query_check_returned->execute();

            if($query_check_returned->rowCount() > 0) {
                // Proceed with issuing the book
                issueBook($dbh, $studentid, $bookid);
            } else {
                $_SESSION['error'] = "Student has already been issued a book with the same ISBN. Please return the book before issuing again.";
            }
        }
        
        header('location:manage-issued-books.php');
        exit(); // Add this to stop further execution of the script after redirection
    }
}

// Function to issue the book
function issueBook($dbh, $studentid, $bookid) {
    // Prepare SQL statement to insert issued book details
    $sql_insert_issue = "INSERT INTO tblissuedbookdetails(StudentID, BookId) VALUES(:studentid, :bookid)";
    $query_insert_issue = $dbh->prepare($sql_insert_issue);
    $query_insert_issue->bindParam(':studentid', $studentid, PDO::PARAM_STR);
    $query_insert_issue->bindParam(':bookid', $bookid, PDO::PARAM_STR);
    $query_insert_issue->execute();

    // Check if the record was inserted successfully
    if($query_insert_issue) {
        // Update quantity in tblbooks table
        $sql_update_qty = "UPDATE tblbooks SET qty = qty - 1 WHERE id = :bookid";
        $query_update_qty = $dbh->prepare($sql_update_qty);
        $query_update_qty->bindParam(':bookid', $bookid, PDO::PARAM_STR);
        $query_update_qty->execute();

        // Check if the quantity was updated successfully
        if($query_update_qty) {
            $_SESSION['msg'] = "Book issued successfully";
        } else {
            $_SESSION['error'] = "Failed to update book quantity";
        }
    } else {
        $_SESSION['error'] = "Failed to issue book";
    }
}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Issue a new Book</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<script>
// function for get student name
function getstudent() {
$("#loaderIcon").show();
jQuery.ajax({
url: "get_student.php",
data:'studentid='+$("#studentid").val(),
type: "POST",
success:function(data){
$("#get_student_name").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

//function for book details
function getbook() {
$("#loaderIcon").show();
jQuery.ajax({
url: "get_book.php",
data:'bookid='+$("#bookid").val(),
type: "POST",
success:function(data){
$("#get_book_name").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

</script> 
<style type="text/css">
  .others{
    color:red;
}

</style>


</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Issue a New Book</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-10 col-sm-6 col-xs-12 col-md-offset-1">
<div class="panel panel-info">
<div class="panel-heading">
Issue a New Book
</div>
<div class="panel-body">
<form role="form" method="post">

<div class="form-group">
<label>Srtudent id<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="studentid" id="studentid" onBlur="getstudent()" autocomplete="off"  required />
</div>

<div class="form-group">
<span id="get_student_name" style="font-size:16px;"></span> 
</div>





<div class="form-group">
<label>ISBN Number or Book Title<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="booikid" id="bookid" onBlur="getbook()"  required="required" />
</div>

 <div class="form-group" id="get_book_name">

 </div>
<button type="submit" name="issue" id="submit" class="btn btn-info">Issue Book </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
<?php  ?>
