<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['alogin']) == 0) {   
    header('location:index.php');
} else { 

    // Calculate fine amount
    $fine = 0;
    if(isset($_POST['issuesDate'])) {
        $issuesDate = strtotime($_POST['issuesDate']);
        $returnDate = strtotime(date('Y-m-d')); // Get current date
        $dueDate = $issuesDate + (7 * 24 * 60 * 60); // 1 week after issue date
        if ($returnDate > $dueDate) {
            $daysLate = floor(($returnDate - $dueDate) / (24 * 60 * 60)); // Calculate days late
            $fine = $daysLate * 5; // 5 Rs fine per day late
        }
    }

    if(isset($_POST['calculate'])) {
        $issuesDate = strtotime($_POST['issuesDate']);
        $returnDate = strtotime(date('Y-m-d')); // Get current date
        $dueDate = $issuesDate + (7 * 24 * 60 * 60); // 1 week after issue date
        $fine = 0;
        if ($returnDate > $dueDate) {
            $daysLate = floor(($returnDate - $dueDate) / (24 * 60 * 60)); // Calculate days late
            $fine = $daysLate * 5; // 5 Rs fine per day late
        }
    }

    if(isset($_POST['return'])) {
        $rid = intval($_GET['rid']);
        $fine = $_POST['fine'];
        $rstatus = 1;
        $bookid = $_POST['bookid'];
        $sql = "UPDATE tblissuedbookdetails SET fine=:fine, RetrunStatus=:rstatus, ReturnDate=NOW() WHERE id=:rid;
                UPDATE tblbooks SET isIssued=0, qty=qty+1 WHERE id=:bookid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':rid', $rid, PDO::PARAM_STR);
        $query->bindParam(':fine', $fine, PDO::PARAM_STR);
        $query->bindParam(':rstatus', $rstatus, PDO::PARAM_STR);
        $query->bindParam(':bookid', $bookid, PDO::PARAM_STR);
        $query->execute();
        $_SESSION['msg'] = "Book returned successfully";
        header('location:manage-issued-books.php');
    }
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Issued Book Details</title>
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- Font Awesome CSS -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <!-- MENU SECTION START-->
    <?php include('includes/header.php');?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Issued Book Details</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            Issued Book Details
                        </div>
                        <div class="panel-body">
                            <form role="form" method="post">
                                <?php 
                                    $rid = intval($_GET['rid']);
                                    $sql = "SELECT tblstudents.StudentId, tblstudents.FullName, tblstudents.EmailId, tblstudents.MobileNumber, tblbooks.BookName, tblbooks.ISBNNumber, tblbooks.bookImage, tblissuedbookdetails.IssuesDate, tblissuedbookdetails.ReturnDate, tblissuedbookdetails.id AS rid, tblissuedbookdetails.fine, tblissuedbookdetails.RetrunStatus, tblbooks.id AS bid FROM tblissuedbookdetails JOIN tblstudents ON tblstudents.StudentId = tblissuedbookdetails.StudentId JOIN tblbooks ON tblbooks.id = tblissuedbookdetails.BookId WHERE tblissuedbookdetails.id = :rid";
                                    $query = $dbh->prepare($sql);
                                    $query->bindParam(':rid', $rid, PDO::PARAM_STR);
                                    $query->execute();
                                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                                    if($query->rowCount() > 0) {
                                        foreach($results as $result) { 
                                ?>                                      
                                <input type="hidden" name="bookid" value="<?php echo htmlentities($result->bid);?>">
                                <div class="form-group">
                                    <label for="studentId">Student ID:</label>
                                    <input type="text" class="form-control" id="studentId" value="<?php echo htmlentities($result->StudentId);?>" disabled>
                                </div>
                                <!-- Other student details -->
                                <!-- Book details -->
                                <div class="form-group">
                                    <label for="bookImage">Book Image:</label>
                                    <br>
                                    <img src="bookimg/<?php echo htmlentities($result->bookImage); ?>" width="120">
                                </div>
                                <div class="form-group">
                                    <label for="issuesDate">Issue Date:</label>
                                    <input type="text" class="form-control" id="issuesDate" value="<?php echo htmlentities($result->IssuesDate);?>" disabled>
                                </div>
                                <!-- Other book details -->
                                <div class="form-group">
                                    <label for="returnDate">Return Date:</label>
                                    <input type="text" class="form-control" id="returnDate" name="returnDate" value="<?php echo date('Y-m-d'); ?>" readonly>
                                </div>
                                <!-- Fine details -->
                                <div class="form-group">
                                    <label for="fine">Fine:</label>
                                    <input type="text" class="form-control" id="fine" name="fine" value="" disabled>
                                </div>
                                <!-- Action buttons -->
                                <button type="button" name="calculate" onclick="calculateFine()" class="btn btn-info">Calculate</button>
                                <button type="submit" name="return" onclick="return validateReturn();" class="btn btn-info">Return Book</button>
                                <input type="hidden" name="issuesDate" value="<?php echo htmlentities($result->IssuesDate);?>">
                                <?php 
                                        }
                                    }
                                ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script>
        // Function to calculate fine amount
        function calculateFine() {
            var issuesDate = $('#issuesDate').val();
            var returnDate = new Date();
            returnDate.setHours(0,0,0,0); // Set time to midnight to compare date only
            var dueDate = new Date(issuesDate);
            dueDate.setDate(dueDate.getDate() + 7); // Add 7 days
            var fine = 0;
            if (returnDate > dueDate) {
                var daysLate = Math.floor((returnDate - dueDate) / (24 * 60 * 60 * 1000)); // Calculate days late
                fine = daysLate * 5; // 5 Rs fine per day late
            }
            $('#fine').val(Math.max(fine, 0)); // Set fine amount in input field
        }

        // Function to validate return action
        function validateReturn() {
            var fine = document.getElementById("fine").value.trim();
            var returnDate = document.getElementById("returnDate").value.trim();
            
            if (fine === "" || returnDate === "") {
                alert("Please fill in the Fine and Return Date fields.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>

<?php } ?>